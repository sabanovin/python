# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')


import requests

class SmsPanel(object):
    """docstring for SmsPanel."""
    def __init__(self):
        super(SmsPanel, self).__init__()
        self.requester = requests.Session()
        self.API_KEY = ''

    def get_balance(self):
        url = 'https://api.sabanovin.com/v1/%s/account/balance.json' %self.API_KEY
        response = self.requester.get(url)
        return response.json()


    def send_single_or_group_sms(self, gateway, to, text):
        if gateway == None:
            raise Exception('Your gateway cant be null')
        if to == None:
            raise Exception('Your reciver numbers cant be null')
        if gateway == None:
            raise Exception('Your text cant be null')
        url = 'https://api.sabanovin.com/v1/%s/sms/send.json' %self.API_KEY
        parameters = dict(
            gateway=gateway,
            to=to,
            text=text)
        response = self.requester.get(url=url, params=parameters)
        return response.json()


    def get_smses(self, gateway, from_date=None, to_date=None, is_read=False):
        if gateway == None:
            raise Exception('Your gateway cant be null')
        if is_read == False:
            is_read = 0
        else:
            is_read = 1
        url = 'https://api.sabanovin.com/v1/%s/sms/receive.json' %self.API_KEY
        parameters = dict(
            gateway=gateway,
            from_date=from_date,
            to_date=to_date,
            is_read=is_read)
        response = self.requester.get(url=url, params=parameters)
        return response.json()

    def add_to_phonebook(self, group_id, number, fname=None, lname=None):
        if group_id == None:
            raise Exception('Your group id cant be null')
        if number == None:
            raise Exception('Your number cant be null')
        url = 'https://api.sabanovin.com/v1/YOUR-API-KEY/utils/add_contact.json'
        parameters = dict(
            group_id=group_id,
            number=number,
            fname=fname,
            lname=lname
        )
        response = self.requester.get(url=url, params=parameters)
        return response.json()

    def pair_to_pair_smses(self, gateway, to, text):
        url = 'https://api.sabanovin.com/v1/%s/sms/send_array.json' %self.API_KEY
        data = dict(
            gateway=gateway,
            to=to,
            text=text,
        )
        response = self.requester.post(url=url, json=data)
        return response.json()
