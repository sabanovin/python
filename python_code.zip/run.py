from tkinter import *
from api import SmsPanel
import json
import ttk
# init Windows


class Gui(object):
    """docstring for Gui"""
    def __init__(self):
        super(Gui, self).__init__()
        self.window = Tk()
        self.window.title("Sms Api")
        self.window.geometry('800x800')
        self.create_elements()
        self.sms_api = SmsPanel()
        self.window.mainloop()

    def create_elements(self):
        lbl_your_api_key = Label(self.window, text="Your Api Key: ")
        lbl_your_api_key.grid(column=0, row=0)
        self.api_key_txt = Entry(self.window,width=70)
        self.api_key_txt.insert(END, 'sa659126429:mLumyhIpZsDYyIo1PNhiPq9O0UpdZiOYoE6q')
        self.api_key_txt.grid(column=1, row=0)

        lbl_your_gateway = Label(self.window, text="Your Gateway: ")
        lbl_your_gateway.grid(column=0, row=1)
        self.gateway_txt = Entry(self.window,width=70)
        self.gateway_txt.insert(END, '10009398238801')
        self.gateway_txt.grid(column=1, row=1)


        separator = ttk.Separator(self.window, orient="horizontal")
        separator.grid(row=2, column=1, sticky="we", )



        get_balance_btn = Button(self.window, text="Get Balance", command=self.get_balance)
        get_balance_btn.grid(column=0, row=3)



        separator = ttk.Separator(self.window, orient="horizontal")
        separator.grid(row=4, column=1, sticky="we", )



        send_single_or_group_sms_btn = Button(self.window, text="Send Single Or Group Sms", command=self.send_single_or_group_sms)
        send_single_or_group_sms_btn.grid(column=0, row=5)

        lbl_single_group_numbers = Label(self.window, text="Numbers(09398238801,09171111111): ")
        lbl_single_group_numbers.grid(column=0, row=6)
        self.single_group_numbers_txt = Entry(self.window, width=70)
        self.single_group_numbers_txt.grid(column=1, row=6)

        lbl_single_group_text = Label(self.window, text="Text: ")
        lbl_single_group_text.grid(column=0, row=7)
        self.single_group_text_txt = Entry(self.window, width=70)
        self.single_group_text_txt.grid(column=1, row=7)


        separator = ttk.Separator(self.window, orient="horizontal")
        separator.grid(row=8, column=1, sticky="we", )





        get_smses_btn = Button(self.window, text="Get Smses", command=self.get_smses)
        get_smses_btn.grid(column=0, row=9)

        lbl_get_sms_from = Label(self.window, text="From Date(1397/01/02): ")
        lbl_get_sms_from.grid(column=0, row=10)
        self.from_date_txt = Entry(self.window, width=70)
        self.from_date_txt.grid(column=1, row=10)

        lbl_get_sms_to = Label(self.window, text="To Date(1397/01/02): ")
        lbl_get_sms_to.grid(column=0, row=11)
        self.to_date_txt = Entry(self.window, width=70)
        self.to_date_txt.grid(column=1, row=11)


        separator = ttk.Separator(self.window, orient="horizontal")
        separator.grid(row=12, column=1, sticky="we", )




        get_smses_btn = Button(self.window, text="Add To Phonebook", command=self.add_to_phonebook)
        get_smses_btn.grid(column=0, row=13)

        lbl_group_id = Label(self.window, text="Group Id: ")
        lbl_group_id.grid(column=0, row=14)
        self.group_id_txt = Entry(self.window, width=70)
        self.group_id_txt.grid(column=1, row=14)

        lbl_number = Label(self.window, text="Number: ")
        lbl_number.grid(column=0, row=15)
        self.number_txt = Entry(self.window, width=70)
        self.number_txt.grid(column=1, row=15)


        separator = ttk.Separator(self.window, orient="horizontal")
        separator.grid(row=16, column=1, sticky="we", )




        pair_to_pair = Button(self.window, text="Send Pair To Pair Sms", command=self.pair_to_pair_sms)
        pair_to_pair.grid(column=0, row=17)

        lbl_numbers_pair = Label(self.window, text="Numbers(09398238801,09171111111): ")
        lbl_numbers_pair.grid(column=0, row=18)
        self.numbers_pair_txt = Entry(self.window, width=70)
        self.numbers_pair_txt.grid(column=1, row=18)

        lbl_texts = Label(self.window, text="Texts: (salam, second txt)")
        lbl_texts.grid(column=0, row=19)
        self.texts_pair_txt = Entry(self.window, width=70)
        self.texts_pair_txt.grid(column=1, row=19)


        separator = ttk.Separator(self.window, orient="horizontal")
        separator.grid(row=20, column=1, sticky="we", )







        lbl_response_code = Label(self.window, text="Response Code: ")
        lbl_response_code.grid(column=0, row=30)
        self.response_code_txt = Entry(self.window,width=70)
        self.response_code_txt.grid(column=1, row=30)

        lbl_message = Label(self.window, text="Message: ")
        lbl_message.grid(column=0, row=31)
        self.message_txt = Entry(self.window,width=70)
        self.message_txt.grid(column=1, row=31)

        lbl_response = Label(self.window, text="Response: ")
        lbl_response.grid(column=0, row=32)
        self.response_txt = Text(self.window,width=70,height=5)
        self.response_txt.grid(column=1, row=32)

    def get_balance(self):
        self.sms_api.API_KEY = self.api_key_txt.get().strip()
        response = self.sms_api.get_balance()
        self.show_result(
            response_code = response['status']['code'],
            message = response['entry']['balance'],
            response = json.dumps(response)
            )

    def send_single_or_group_sms(self):
        self.sms_api.API_KEY = self.api_key_txt.get().strip()
        gateway = self.gateway_txt.get().strip()
        to = self.single_group_numbers_txt.get().strip()
        text = self.single_group_text_txt.get().strip()
        response = self.sms_api.send_single_or_group_sms(gateway, to, text)
        print response
        self.show_result(
            response_code = response['status']['code'],
            message = response['status']['message'],
            response = json.dumps(response)
            )

    def get_smses(self):
        self.sms_api.API_KEY = self.api_key_txt.get().strip()
        gateway = self.gateway_txt.get().strip()
        from_date = self.from_date_txt.get().strip() or None
        to_date = self.to_date_txt.get().strip() or None
        response = self.sms_api.get_smses(gateway, from_date, to_date)
        self.show_result(
            response_code = response['status']['code'],
            message = response['status']['message'],
            response = json.dumps(response)
            )

    def add_to_phonebook(self):
        self.sms_api.API_KEY = self.api_key_txt.get().strip()
        gateway = self.gateway_txt.get().strip()
        group_id = self.from_date_txt.get().strip()
        number = self.to_date_txt.get().strip()
        response = self.sms_api.add_to_phonebook(gateway, group_id, number)
        self.show_result(
            response_code = response['status']['code'],
            message = response['status']['message'],
            response = json.dumps(response)
            )

    def pair_to_pair_sms(self):
        self.sms_api.API_KEY = self.api_key_txt.get().strip()
        gateway = self.gateway_txt.get().strip()
        numbers = self.numbers_pair_txt.get().strip().split(',')
        texts = self.texts_pair_txt.get().strip().split(',')
        # print numbers
        # print texts
        response = self.sms_api.pair_to_pair_smses(gateway, numbers, texts)
        self.show_result(
            response_code = response['status']['code'],
            message = response['status']['message'],
            response = json.dumps(response)
            )
        # 09398238801,09398238801

    def show_result(self, response_code, message, response):
        self.response_code_txt.delete(0, END)
        self.response_code_txt.insert(0, response_code)

        self.message_txt.delete(0, END)
        self.message_txt.insert(0, message)

        self.response_txt.delete('1.0', END)
        self.response_txt.insert(END, response)


Gui()